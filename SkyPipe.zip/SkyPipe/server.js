 const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Initialize app
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb+srv://SkyPIPE:PassWord25WA@cclskypipe.5fezu.mongodb.net/?retryWrites=true&w=majority&appName=CCLSKYPIPE', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Define a schema for videos
const videoSchema = new mongoose.Schema({
    title: String,
    videoPath: String,
});

const Video = mongoose.model('Video', videoSchema);

// Serve static files
app.use(express.static('uploads'));
app.use(express.urlencoded({ extended: true }));

// Multer setup for video uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});

const upload = multer({ storage });

// Serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle video upload
app.post('/upload', upload.single('video'), async (req, res) => {
    const { title } = req.body;
    const videoPath = req.file.filename;

    const newVideo = new Video({ title, videoPath });
    await newVideo.save();

    res.redirect('/');
});

// Fetch all videos
app.get('/videos', async (req, res) => {
    const videos = await Video.find();
    res.json(videos);
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

